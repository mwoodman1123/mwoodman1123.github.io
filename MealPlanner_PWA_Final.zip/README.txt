Meal Planner PWA + iCloud Sync

Files:
- index.html (your full app + PWA + iCloud sync hooks)
- manifest.json
- sw.js
- sync.js
- icon-192.png
- icon-512.png

How to use:
1. Upload all these files to a static host (GitHub Pages, Netlify, Vercel, etc.).
2. Open the site in Safari on your iPhone.
3. Tap Share -> "Add to Home Screen" to install.
4. Use the app normally. Data will be synced via iCloud across devices that load the same URL.
